//Q6:
//a) "A's no-arg constructor is invoked"
//b) A's no-arg constructor has not been declared, compilation error.

//Q7:
//replace every radius before = with this.radius
//calling of Circle's constructor should be using the word super not the class name.
//getArea should be super.getArea()

//Q8: overridden

//Q9: yes

