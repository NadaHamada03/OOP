public class Employee extends Person{
    String office;
    double salary;
    java.util.Date hire_date = new java.util.Date();

    public String toString() {
        return name + " Employee";
    }
}
