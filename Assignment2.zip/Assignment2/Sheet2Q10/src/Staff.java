public class Staff extends Employee{
    String title;

    public String toString() {
        return name + " Staff";
    }
}
