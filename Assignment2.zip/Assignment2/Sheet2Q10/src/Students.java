public class Students extends Person{
    final String status1 = "Freshman";
    final String status2 = "Sophomore";
    final String status3 = "Junior";
    final String status4 = "Senior";

    public String toString() {
        return name + " Student";
    }
}
