public class Faculty extends Employee{
    double hours;
    String rank;

    public String toString() {
        return name + " Faculty";
    }
}
