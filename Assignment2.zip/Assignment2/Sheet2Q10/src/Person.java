public class Person {
    String name;
    String address;
    String phone_number;
    String email;

    public String toString() {
        return  name + " Person";
    }
}
