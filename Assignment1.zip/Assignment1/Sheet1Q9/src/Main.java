import java.util.*;
import java.io.*;
import java.math.*;
import java.net.*;

public class Main
{
    public static void main(String[] args)
    {

    }
}
public class Test
{
    private int id;
    public void m1() { this.id = 45;}
    public void m2() { Test.id = 45;} //variable if is not static in order to access it with the class name.
}