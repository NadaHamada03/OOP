import java.io.*;
import java.util.*;
import java.lang.*;

public class Main {
    public static void main(String[] args)
    {
        // Check if the file exist
        String filename = "myFile.txt";
        File file = new File(filename);

        if(!file.exists())
        {
            System.out.println("Source file " + filename + " does not exist");
        }

        try
        {
            Scanner input = new Scanner(file);
            String s = "";

            while (input.hasNext())
            {
                s += input.nextLine();
            }

            System.out.println("Enter an item to remove:");
            String toRemove = input.next();

            s.replaceAll(toRemove,"");

            PrintWriter output = new PrintWriter(file);
            output.println(s);

            output.close();
            input.close();
        }
        catch (FileNotFoundException e)
        {
            System.out.println(" does not exist.");
        }

    }
}