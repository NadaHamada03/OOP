import java.util.*;
import java.lang.*;
import java.io.*;
public class Main {
    public static void main(String[] args)
    {
        try
        {
            java.net.URL url = new java.net.URL("http://cs.armstrong.edu/liang/data/Lincoln.txt");

            Scanner input = new Scanner(url.openStream());

            int count=0;

            while (input.hasNext())
            {
                if (Character.isLetter((input.next()).charAt(0))) {
                    count++;
                }
            }

            // Display result
            System.out.println("Number of words in President Abraham Lincoln's Gettysburg address: " + count);
        }
        catch (java.net.MalformedURLException ex)
        {
            System.out.println("Invalid URL");
        }
        catch (java.io.IOException ex)
        {
            System.out.println("I/0 Errors: no such file");
        }
    }
}