import java.util.*;
import java.lang.*;
public class Main {
    public static void main(String[] args)
    {
        try
        {
            Scanner input = new Scanner(System.in);

            ArrayList<Integer> numbers = new ArrayList<>();

            for(int i=0; i<5; i++)
            {
                System.out.println("Enter a number for element "+(i+1)+":");
                numbers.add(input.nextInt()); //may throw exception if entered item is of mismatching types with int, for example: character.
            }

            for(int i=0; i<5; i++)
            {
                System.out.println(numbers.get(i));
            }

            Collections.sort(numbers);

            for(int i=0; i<5; i++)
            {
                System.out.println(numbers.get(i));
            }
        }
        catch(InputMismatchException e)
        {
            System.out.println("Please enter an integer.");
        }
    }
}